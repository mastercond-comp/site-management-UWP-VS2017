<?php 
  $content = get_content();  
  $pattern = "#<Valute ID=\"([^\"]+)[^>]+>[^>]+>([^<]+)[^>]+>[^>]+>[^>]+>[^>]+>[^>]+>[^>]+>([^<]+)[^>]+>[^>]+>([^<]+)#i"; 
  preg_match_all($pattern, $content, $out, PREG_SET_ORDER); 
  $dollar = ""; 
  $euro = ""; 
  foreach($out as $cur) 
  { 
    if($cur[2] == 840) $dollar = str_replace(",",".",$cur[4]); 
    if($cur[2] == 978) $euro   = str_replace(",",".",$cur[4]); 
  } 
  echo "Dollar - ".$dollar."<br>"; 
  echo "Euro - ".$euro."<br>"; 
  function get_content() 
  { 
    
    $date = date("d/m/Y"); 
    $link = "http://www.cbr.ru/scripts/XML_daily.asp?date_req=$date";  
    $fd = fopen($link, "r"); 
    $text=""; 
    if (!$fd) echo "Page not found :("; 
    else 
    { 
      while (!feof ($fd)) $text .= fgets($fd, 4096); 
    } 
    fclose ($fd); 
    return $text; 
  } 
	$eurotable=$dollar/$euro;

$fh1=fopen("/public_html/dollar.ini","w");
$line1 = fwrite($fh1,$dollar);
fclose($fh1);

$fh2=fopen("/public_html/euro.ini","w");
$line2 = fwrite($fh2,$euro);
fclose($fh2);

?>